# MemberRegistrationApi

All URIs are relative to *https://localhost/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**registerMember**](MemberRegistrationApi.md#registerMember) | **POST** /registration | Member Registration Endpoint.


<a name="registerMember"></a>
# **registerMember**
> Success registerMember(memberDetails)

Member Registration Endpoint.

This API is used to register memebrs. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.MemberRegistrationApi;


MemberRegistrationApi apiInstance = new MemberRegistrationApi();
MemberDetails memberDetails = new MemberDetails(); // MemberDetails | The details of the new member to be registered.
try {
    Success result = apiInstance.registerMember(memberDetails);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberRegistrationApi#registerMember");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **memberDetails** | [**MemberDetails**](MemberDetails.md)| The details of the new member to be registered. | [optional]

### Return type

[**Success**](Success.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

