
# MemberDetailsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memberName** | **String** |  | 
**memberAge** | **Integer** |  | 



